from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from flask_socketio import emit, join_room, leave_room
from app import app, db, socketio
from models import User, WorkerProfile, Booking, Feedback, Skill
from datetime import datetime
import json

def register_routes(app):
    
    @app.route('/')
    def index():
        # Get featured workers for homepage
        featured_workers = WorkerProfile.query.filter_by(
            is_active=True, 
            availability_status='free'
        ).order_by(WorkerProfile.rating.desc()).limit(6).all()
        return render_template('index.html', featured_workers=featured_workers)
    
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            
            if user and user.check_password(password):
                login_user(user)
                next_page = request.args.get('next')
                if user.user_type == 'worker':
                    return redirect(next_page) if next_page else redirect(url_for('worker_dashboard'))
                else:
                    return redirect(next_page) if next_page else redirect(url_for('client_dashboard'))
            else:
                flash('Invalid username or password', 'error')
        
        return render_template('login.html')
    
    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            user_type = request.form['user_type']
            
            # Check if user already exists
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'error')
                return render_template('register.html')
            
            if User.query.filter_by(email=email).first():
                flash('Email already exists', 'error')
                return render_template('register.html')
            
            # Create new user
            user = User(username=username, email=email, user_type=user_type)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            
            # Create worker profile if user is a worker
            if user_type == 'worker':
                worker_profile = WorkerProfile(
                    user_id=user.id,
                    full_name=request.form.get('full_name', ''),
                    phone=request.form.get('phone', ''),
                    skills=json.dumps(request.form.getlist('skills')),
                    hourly_rate=float(request.form.get('hourly_rate', 0)),
                    bio=request.form.get('bio', ''),
                    latitude=float(request.form.get('latitude', 0)) if request.form.get('latitude') else None,
                    longitude=float(request.form.get('longitude', 0)) if request.form.get('longitude') else None
                )
                db.session.add(worker_profile)
                db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        
        # Get available skills for the form
        skills = ['Plumbing', 'Electrical', 'Carpentry', 'Painting', 'Cleaning', 'Gardening', 'Repair', 'Installation']
        return render_template('register.html', skills=skills)
    
    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('index'))
    
    @app.route('/worker/dashboard')
    @login_required
    def worker_dashboard():
        if current_user.user_type != 'worker':
            flash('Access denied', 'error')
            return redirect(url_for('index'))
        
        profile = WorkerProfile.query.filter_by(user_id=current_user.id).first()
        if not profile:
            flash('Please complete your worker profile', 'warning')
            return redirect(url_for('worker_profile'))
        
        # Get worker's bookings
        bookings = Booking.query.filter_by(worker_id=current_user.id).order_by(
            Booking.created_at.desc()
        ).all()
        
        return render_template('worker_dashboard.html', profile=profile, bookings=bookings)
    
    @app.route('/client/dashboard')
    @login_required
    def client_dashboard():
        if current_user.user_type != 'client':
            flash('Access denied', 'error')
            return redirect(url_for('index'))
        
        # Get client's bookings
        bookings = Booking.query.filter_by(client_id=current_user.id).order_by(
            Booking.created_at.desc()
        ).all()
        
        return render_template('client_dashboard.html', bookings=bookings)
    
    @app.route('/worker/profile', methods=['GET', 'POST'])
    @login_required
    def worker_profile():
        if current_user.user_type != 'worker':
            flash('Access denied', 'error')
            return redirect(url_for('index'))
        
        profile = WorkerProfile.query.filter_by(user_id=current_user.id).first()
        
        if request.method == 'POST':
            if not profile:
                profile = WorkerProfile(user_id=current_user.id)
                db.session.add(profile)
            
            profile.full_name = request.form['full_name']
            profile.phone = request.form['phone']
            profile.skills = json.dumps(request.form.getlist('skills'))
            profile.experience_years = int(request.form.get('experience_years', 0))
            profile.hourly_rate = float(request.form.get('hourly_rate', 0))
            profile.bio = request.form['bio']
            profile.latitude = float(request.form.get('latitude', 0)) if request.form.get('latitude') else None
            profile.longitude = float(request.form.get('longitude', 0)) if request.form.get('longitude') else None
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('worker_dashboard'))
        
        skills = ['Plumbing', 'Electrical', 'Carpentry', 'Painting', 'Cleaning', 'Gardening', 'Repair', 'Installation']
        return render_template('worker_profile.html', profile=profile, skills=skills)
    
    @app.route('/book_worker/<int:worker_id>', methods=['GET', 'POST'])
    @login_required
    def book_worker(worker_id):
        if current_user.user_type != 'client':
            flash('Access denied', 'error')
            return redirect(url_for('index'))
        
        worker = User.query.get_or_404(worker_id)
        worker_profile = WorkerProfile.query.filter_by(user_id=worker_id).first()
        
        if not worker_profile:
            flash('Worker profile not found', 'error')
            return redirect(url_for('index'))
        
        if request.method == 'POST':
            booking = Booking(
                client_id=current_user.id,
                worker_id=worker_id,
                service_description=request.form['service_description'],
                required_skills=json.dumps(request.form.getlist('required_skills')),
                scheduled_date=datetime.strptime(request.form['scheduled_date'], '%Y-%m-%dT%H:%M'),
                duration_hours=float(request.form['duration_hours']),
                client_address=request.form['client_address'],
                client_latitude=float(request.form.get('client_latitude', 0)) if request.form.get('client_latitude') else None,
                client_longitude=float(request.form.get('client_longitude', 0)) if request.form.get('client_longitude') else None
            )
            
            # Calculate total amount
            booking.total_amount = booking.duration_hours * worker_profile.hourly_rate
            
            db.session.add(booking)
            db.session.commit()
            
            # Emit real-time notification to worker
            socketio.emit('new_booking', {
                'booking_id': booking.id,
                'client_name': current_user.username,
                'service': booking.service_description
            }, room=f'worker_{worker_id}')
            
            flash('Booking request sent successfully!', 'success')
            return redirect(url_for('client_dashboard'))
        
        return render_template('booking_form.html', worker=worker, worker_profile=worker_profile)
    
    @app.route('/map')
    def map_view():
        # Get all active workers with location data
        workers = WorkerProfile.query.filter(
            WorkerProfile.is_active == True,
            WorkerProfile.latitude.isnot(None),
            WorkerProfile.longitude.isnot(None)
        ).all()
        
        workers_data = []
        for worker in workers:
            workers_data.append({
                'id': worker.user_id,
                'name': worker.full_name,
                'lat': worker.latitude,
                'lng': worker.longitude,
                'status': worker.availability_status,
                'skills': worker.get_skills_list(),
                'rating': worker.rating,
                'hourly_rate': worker.hourly_rate
            })
        
        return render_template('map.html', workers_data=json.dumps(workers_data))
    
    @app.route('/update_status', methods=['POST'])
    @login_required
    def update_status():
        if current_user.user_type != 'worker':
            return jsonify({'error': 'Access denied'}), 403
        
        profile = WorkerProfile.query.filter_by(user_id=current_user.id).first()
        if not profile:
            return jsonify({'error': 'Profile not found'}), 404
        
        new_status = request.json.get('status')
        if new_status in ['free', 'busy', 'dnd']:
            profile.availability_status = new_status
            profile.update_last_seen()
            db.session.commit()
            
            # Emit status update to all connected clients
            socketio.emit('status_update', {
                'worker_id': current_user.id,
                'status': new_status
            }, broadcast=True)
            
            return jsonify({'success': True})
        
        return jsonify({'error': 'Invalid status'}), 400
    
    @app.route('/booking/<int:booking_id>/update_status', methods=['POST'])
    @login_required
    def update_booking_status(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        
        # Check permissions
        if current_user.id != booking.worker_id and current_user.id != booking.client_id:
            flash('Access denied', 'error')
            return redirect(url_for('index'))
        
        new_status = request.form['status']
        if new_status in ['confirmed', 'in_progress', 'completed', 'cancelled']:
            booking.status = new_status
            booking.updated_at = datetime.utcnow()
            
            # Update worker availability based on booking status
            if current_user.id == booking.worker_id:
                worker_profile = WorkerProfile.query.filter_by(user_id=booking.worker_id).first()
                if worker_profile:
                    if new_status == 'in_progress':
                        worker_profile.availability_status = 'busy'
                    elif new_status in ['completed', 'cancelled']:
                        worker_profile.availability_status = 'free'
                        if new_status == 'completed':
                            worker_profile.total_jobs += 1
            
            db.session.commit()
            
            # Emit real-time update
            socketio.emit('booking_update', {
                'booking_id': booking.id,
                'status': new_status
            }, room=f'user_{booking.client_id}')
            
            socketio.emit('booking_update', {
                'booking_id': booking.id,
                'status': new_status
            }, room=f'user_{booking.worker_id}')
            
            flash(f'Booking status updated to {new_status}', 'success')
        
        return redirect(request.referrer or url_for('index'))
    
    @app.route('/booking/<int:booking_id>/feedback', methods=['POST'])
    @login_required
    def submit_feedback(booking_id):
        booking = Booking.query.get_or_404(booking_id)
        
        # Only client can submit feedback and only for completed bookings
        if current_user.id != booking.client_id or booking.status != 'completed':
            flash('Cannot submit feedback for this booking', 'error')
            return redirect(request.referrer or url_for('index'))
        
        # Check if feedback already exists
        if booking.feedback:
            flash('Feedback already submitted for this booking', 'warning')
            return redirect(request.referrer or url_for('index'))
        
        feedback = Feedback(
            booking_id=booking_id,
            rating=int(request.form['rating']),
            comment=request.form['comment']
        )
        
        db.session.add(feedback)
        db.session.commit()
        
        flash('Feedback submitted successfully!', 'success')
        return redirect(url_for('client_dashboard'))

# Socket.IO event handlers
@socketio.on('connect')
def handle_connect():
    if current_user.is_authenticated:
        join_room(f'user_{current_user.id}')
        if current_user.user_type == 'worker':
            join_room(f'worker_{current_user.id}')
            # Update last seen time
            profile = WorkerProfile.query.filter_by(user_id=current_user.id).first()
            if profile:
                profile.update_last_seen()

@socketio.on('disconnect')
def handle_disconnect():
    if current_user.is_authenticated:
        leave_room(f'user_{current_user.id}')
        if current_user.user_type == 'worker':
            leave_room(f'worker_{current_user.id}')

@socketio.on('worker_location_update')
def handle_location_update(data):
    if current_user.is_authenticated and current_user.user_type == 'worker':
        profile = WorkerProfile.query.filter_by(user_id=current_user.id).first()
        if profile:
            profile.latitude = data['lat']
            profile.longitude = data['lng']
            profile.update_last_seen()
            db.session.commit()
            
            # Broadcast location update
            emit('worker_moved', {
                'worker_id': current_user.id,
                'lat': data['lat'],
                'lng': data['lng']
            }, broadcast=True)
