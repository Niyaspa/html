# Niyas Worker App

## Overview

This is a Flask-based worker booking application that connects clients with skilled workers based on location. The app provides real-time matching, booking management, and interactive map-based worker discovery. It features a dual-user system supporting both service providers (workers) and service seekers (clients).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **CSS Framework**: Bootstrap 5 with dark theme
- **JavaScript Libraries**: 
  - Leaflet.js for interactive maps
  - Socket.IO for real-time communication
  - Font Awesome for icons
- **Responsive Design**: Mobile-first approach with Bootstrap grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension
- **Authentication**: Flask-Login for session management
- **Real-time Communication**: Flask-SocketIO for WebSocket connections
- **Security**: Werkzeug for password hashing and proxy handling

### Database Architecture
- **Primary Database**: SQLite (configurable to PostgreSQL via DATABASE_URL)
- **Schema Design**: Relational model with the following entities:
  - Users (authentication and basic info)
  - WorkerProfiles (worker-specific data including location and skills)
  - Bookings (service requests and status tracking)
  - Skills and Feedback (referenced but not fully implemented in visible code)

## Key Components

### Authentication System
- Role-based access control (client/worker user types)
- Session-based authentication using Flask-Login
- Password hashing with Werkzeug security utilities
- Registration flow with user type selection

### Location Services
- GPS coordinate storage for workers
- Map-based worker discovery using Leaflet.js
- Real-time location tracking and updates
- Distance-based matching capabilities

### Booking System
- Service request creation and management
- Status tracking (pending, confirmed, completed, etc.)
- Real-time notifications via WebSocket
- Worker availability management

### Real-time Features
- Socket.IO integration for live updates
- Worker status broadcasting
- Booking notifications
- Connection status monitoring

## Data Flow

### User Registration & Authentication
1. User selects account type (client/worker)
2. Basic registration with username/email/password
3. Workers complete additional profile setup
4. Authentication via Flask-Login sessions

### Worker Discovery
1. Client accesses map view
2. System queries workers by location and availability
3. Map displays workers with status indicators
4. Filtering by skills, status, and distance

### Booking Process
1. Client selects worker from map or list
2. Booking form submitted with service details
3. Real-time notification sent to worker
4. Worker accepts/declines booking
5. Status updates broadcast to both parties

### Worker Management
1. Workers set availability status
2. Location updates tracked automatically
3. Profile management for skills and rates
4. Job completion and rating system

## External Dependencies

### Frontend Libraries
- **Bootstrap 5**: UI framework and responsive design
- **Leaflet.js**: Interactive mapping functionality
- **Font Awesome**: Icon library
- **Socket.IO Client**: Real-time communication

### Backend Packages
- **Flask**: Web framework
- **Flask-SQLAlchemy**: Database ORM
- **Flask-Login**: Authentication management
- **Flask-SocketIO**: WebSocket support
- **Werkzeug**: Security utilities

### Database
- **SQLite**: Default database (development)
- **PostgreSQL**: Production database option via DATABASE_URL

## Deployment Strategy

### Configuration
- Environment-based configuration using os.environ
- Configurable database URL for different environments
- Secret key management for session security
- Proxy fix middleware for production deployment

### Development Setup
- Debug mode enabled in main.py
- SQLAlchemy table auto-creation
- Socket.IO with CORS enabled for development
- File-based SQLite database

### Production Considerations
- Database connection pooling configured
- ProxyFix middleware for reverse proxy deployments
- Environment variable configuration for secrets
- Socket.IO CORS configuration for production domains

### Scalability Features
- Database connection pool with recycling
- Real-time communication via WebSocket
- Stateless session management
- Location-based data partitioning potential

The application follows a modular Flask structure with clear separation between models, routes, and templates. The real-time features and location-based matching make it suitable for on-demand service platforms, while the dual-user system accommodates both service providers and consumers effectively.