// Main application JavaScript
// Handles Socket.IO connections, notifications, and common UI functionality

// Global variables
let socket;
let isConnected = false;

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeSocket();
    initializeCommonUI();
    initializeFormValidation();
    setupNotificationSystem();
});

// Socket.IO initialization and event handlers
function initializeSocket() {
    try {
        socket = io();
        
        socket.on('connect', function() {
            isConnected = true;
            console.log('Connected to server');
            updateConnectionStatus(true);
        });
        
        socket.on('disconnect', function() {
            isConnected = false;
            console.log('Disconnected from server');
            updateConnectionStatus(false);
        });
        
        // Handle real-time booking notifications
        socket.on('new_booking', function(data) {
            showNotification('New Booking Request', 
                `New booking from ${data.client_name} for ${data.service}`, 
                'info');
        });
        
        // Handle booking status updates
        socket.on('booking_update', function(data) {
            showNotification('Booking Update', 
                `Booking #${data.booking_id} status changed to ${data.status.replace('_', ' ')}`, 
                'info');
            
            // Update booking status on current page if visible
            updateBookingStatusUI(data.booking_id, data.status);
        });
        
        // Handle worker status updates
        socket.on('status_update', function(data) {
            updateWorkerStatusUI(data.worker_id, data.status);
        });
        
        // Handle worker location updates
        socket.on('worker_moved', function(data) {
            if (typeof updateWorkerLocation === 'function') {
                updateWorkerLocation(data.worker_id, data.lat, data.lng);
            }
        });
        
    } catch (error) {
        console.error('Socket.IO initialization error:', error);
    }
}

// Update connection status indicator
function updateConnectionStatus(connected) {
    const indicators = document.querySelectorAll('.status-indicator');
    indicators.forEach(indicator => {
        indicator.className = connected ? 
            'status-indicator online' : 
            'status-indicator offline';
    });
}

// Common UI initialization
function initializeCommonUI() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide alerts
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            if (alert.classList.contains('alert-success') || 
                alert.classList.contains('alert-info')) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        });
    }, 5000);
    
    // Add loading states to buttons
    setupButtonLoading();
    
    // Setup mobile menu handling
    setupMobileNavigation();
}

// Form validation enhancement
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation, form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Focus first invalid field
                const firstInvalid = form.querySelector(':invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                }
            } else {
                // Add loading state to submit button
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn) {
                    addButtonLoading(submitBtn);
                }
            }
            
            form.classList.add('was-validated');
        });
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (this.checkValidity()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                }
            });
        });
    });
}

// Notification system
function setupNotificationSystem() {
    // Create notification container if it doesn't exist
    if (!document.getElementById('notificationContainer')) {
        const container = document.createElement('div');
        container.id = 'notificationContainer';
        container.className = 'notification';
        document.body.appendChild(container);
    }
}

function showNotification(title, message, type = 'info', duration = 5000) {
    const container = document.getElementById('notificationContainer');
    if (!container) return;
    
    const alertClass = `alert-${type === 'error' ? 'danger' : type}`;
    const iconClass = type === 'success' ? 'fa-check-circle' : 
                     type === 'error' ? 'fa-exclamation-circle' : 
                     type === 'warning' ? 'fa-exclamation-triangle' : 
                     'fa-info-circle';
    
    const notification = document.createElement('div');
    notification.className = `alert ${alertClass} alert-dismissible fade show`;
    notification.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas ${iconClass} me-2"></i>
            <div>
                <strong>${title}</strong>
                <div>${message}</div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    container.appendChild(notification);
    
    // Auto-remove after duration
    if (duration > 0) {
        setTimeout(() => {
            if (notification.parentNode) {
                const bsAlert = new bootstrap.Alert(notification);
                bsAlert.close();
            }
        }, duration);
    }
}

// Button loading states
function setupButtonLoading() {
    document.addEventListener('click', function(e) {
        if (e.target.matches('button[type="submit"], .btn-loading')) {
            addButtonLoading(e.target);
        }
    });
}

function addButtonLoading(button) {
    if (button.classList.contains('loading')) return;
    
    button.classList.add('loading');
    button.disabled = true;
    
    const originalText = button.innerHTML;
    button.setAttribute('data-original-text', originalText);
    
    const loadingText = button.getAttribute('data-loading-text') || 'Loading...';
    button.innerHTML = `<span class="loading me-2"></span>${loadingText}`;
}

function removeButtonLoading(button) {
    button.classList.remove('loading');
    button.disabled = false;
    
    const originalText = button.getAttribute('data-original-text');
    if (originalText) {
        button.innerHTML = originalText;
    }
}

// Mobile navigation handling
function setupMobileNavigation() {
    const navbar = document.querySelector('.navbar-collapse');
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navbar && navbar.classList.contains('show')) {
                const bsCollapse = new bootstrap.Collapse(navbar);
                bsCollapse.hide();
            }
        });
    });
}

// Update booking status in UI
function updateBookingStatusUI(bookingId, status) {
    const statusElements = document.querySelectorAll(`[data-booking-id="${bookingId}"] .booking-status`);
    statusElements.forEach(element => {
        element.className = `badge status-${status}`;
        element.textContent = status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
    });
}

// Update worker status in UI
function updateWorkerStatusUI(workerId, status) {
    const statusElements = document.querySelectorAll(`[data-worker-id="${workerId}"] .worker-status`);
    statusElements.forEach(element => {
        element.className = `badge status-${status}`;
        element.textContent = status === 'free' ? 'Available' :
                             status === 'busy' ? 'Busy' :
                             'Do Not Disturb';
    });
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDistance(distance) {
    if (distance < 1000) {
        return `${Math.round(distance)} m`;
    } else {
        return `${(distance / 1000).toFixed(1)} km`;
    }
}

// Calculate distance between two coordinates
function calculateDistance(lat1, lng1, lat2, lng2) {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lng2 - lng1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
}

// Debounce function for search inputs
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// Local storage helpers
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error('Error saving to localStorage:', error);
    }
}

function getFromLocalStorage(key, defaultValue = null) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : defaultValue;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return defaultValue;
    }
}

// Enhanced geolocation with error handling
function getCurrentPosition(options = {}) {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocation is not supported by this browser'));
            return;
        }
        
        const defaultOptions = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
        };
        
        navigator.geolocation.getCurrentPosition(
            resolve,
            reject,
            { ...defaultOptions, ...options }
        );
    });
}

// Image lazy loading
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    } else {
        // Fallback for older browsers
        images.forEach(img => {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
        });
    }
}

// Search functionality
function initializeSearch() {
    const searchInputs = document.querySelectorAll('.search-input');
    
    searchInputs.forEach(input => {
        const searchFunction = debounce(function(e) {
            const query = e.target.value.toLowerCase().trim();
            const searchableElements = document.querySelectorAll('.searchable');
            
            searchableElements.forEach(element => {
                const text = element.textContent.toLowerCase();
                const shouldShow = query === '' || text.includes(query);
                element.style.display = shouldShow ? '' : 'none';
            });
        }, 300);
        
        input.addEventListener('input', searchFunction);
    });
}

// Performance monitoring
function logPerformance(name, startTime) {
    if (performance && performance.now) {
        const duration = performance.now() - startTime;
        console.log(`${name} took ${duration.toFixed(2)}ms`);
    }
}

// Error boundary for JavaScript errors
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    
    // Show user-friendly error message for critical errors
    if (e.error && e.error.message) {
        showNotification('Error', 
            'Something went wrong. Please refresh the page and try again.', 
            'error');
    }
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
    showNotification('Error', 
        'An unexpected error occurred. Please try again.', 
        'error');
});

// Export functions for use in other scripts
window.WorkerApp = {
    showNotification,
    addButtonLoading,
    removeButtonLoading,
    formatCurrency,
    formatDate,
    formatDistance,
    calculateDistance,
    getCurrentPosition,
    saveToLocalStorage,
    getFromLocalStorage,
    debounce
};
