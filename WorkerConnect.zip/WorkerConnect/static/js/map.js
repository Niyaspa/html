// Map-specific functionality and utilities
// Extends the map functionality beyond what's in map.html

// Map utility functions and enhancements
class MapUtils {
    constructor() {
        this.defaultCenter = [40.7128, -74.0060]; // New York City
        this.defaultZoom = 10;
    }
    
    // Create custom markers with enhanced styling
    createWorkerMarker(worker, options = {}) {
        const defaultOptions = {
            iconSize: [30, 30],
            iconAnchor: [15, 30],
            popupAnchor: [0, -30]
        };
        
        const markerOptions = { ...defaultOptions, ...options };
        
        const statusColors = {
            free: '#28a745',
            busy: '#ffc107', 
            dnd: '#dc3545'
        };
        
        const color = statusColors[worker.status] || '#6c757d';
        
        return L.divIcon({
            className: 'custom-worker-marker',
            html: `
                <div class="marker-container">
                    <div class="marker-pin" style="background-color: ${color};">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="marker-pulse" style="background-color: ${color};"></div>
                </div>
            `,
            iconSize: markerOptions.iconSize,
            iconAnchor: markerOptions.iconAnchor,
            popupAnchor: markerOptions.popupAnchor
        });
    }
    
    // Create user location marker
    createUserMarker(options = {}) {
        const defaultOptions = {
            iconSize: [25, 25],
            iconAnchor: [12, 12]
        };
        
        const markerOptions = { ...defaultOptions, ...options };
        
        return L.divIcon({
            className: 'custom-user-marker',
            html: `
                <div class="user-marker-container">
                    <div class="user-marker-dot"></div>
                    <div class="user-marker-circle"></div>
                </div>
            `,
            iconSize: markerOptions.iconSize,
            iconAnchor: markerOptions.iconAnchor
        });
    }
    
    // Calculate and display route between two points
    async calculateRoute(fromLat, fromLng, toLat, toLng, map) {
        try {
            // Using a simple straight line for now
            // In a real application, you might want to use a routing service
            const routeLine = L.polyline([
                [fromLat, fromLng],
                [toLat, toLng]
            ], {
                color: '#007bff',
                weight: 4,
                opacity: 0.7,
                dashArray: '10, 10'
            }).addTo(map);
            
            const distance = this.calculateDistance(fromLat, fromLng, toLat, toLng);
            const estimatedTime = this.estimateTime(distance);
            
            return {
                line: routeLine,
                distance: distance,
                estimatedTime: estimatedTime
            };
        } catch (error) {
            console.error('Error calculating route:', error);
            return null;
        }
    }
    
    // Calculate distance between two points
    calculateDistance(lat1, lng1, lat2, lng2) {
        const R = 6371; // Earth's radius in kilometers
        const dLat = this.toRadians(lat2 - lat1);
        const dLng = this.toRadians(lng2 - lng1);
        
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
                  Math.sin(dLng / 2) * Math.sin(dLng / 2);
        
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
    
    // Convert degrees to radians
    toRadians(degrees) {
        return degrees * (Math.PI / 180);
    }
    
    // Estimate travel time based on distance
    estimateTime(distanceKm) {
        // Assuming average speed of 40 km/h in urban areas
        const averageSpeed = 40;
        const timeHours = distanceKm / averageSpeed;
        const timeMinutes = Math.round(timeHours * 60);
        
        if (timeMinutes < 60) {
            return `${timeMinutes} min`;
        } else {
            const hours = Math.floor(timeMinutes / 60);
            const minutes = timeMinutes % 60;
            return `${hours}h ${minutes}m`;
        }
    }
    
    // Fit map bounds to show all markers
    fitBoundsToMarkers(map, markers) {
        if (markers.length === 0) return;
        
        const group = new L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
    
    // Find nearest workers to a location
    findNearestWorkers(userLat, userLng, workers, limit = 5) {
        const workersWithDistance = workers.map(worker => ({
            ...worker,
            distance: this.calculateDistance(userLat, userLng, worker.lat, worker.lng)
        }));
        
        return workersWithDistance
            .sort((a, b) => a.distance - b.distance)
            .slice(0, limit);
    }
    
    // Create area of service circle around worker
    createServiceArea(lat, lng, radiusKm, map, options = {}) {
        const defaultOptions = {
            color: '#007bff',
            fillColor: '#007bff',
            fillOpacity: 0.1,
            weight: 2
        };
        
        const circleOptions = { ...defaultOptions, ...options };
        
        return L.circle([lat, lng], {
            radius: radiusKm * 1000, // Convert km to meters
            ...circleOptions
        }).addTo(map);
    }
    
    // Cluster markers for better performance
    createMarkerCluster(markers, options = {}) {
        if (typeof L.markerClusterGroup === 'undefined') {
            console.warn('Leaflet MarkerCluster plugin not loaded');
            return null;
        }
        
        const defaultOptions = {
            chunkedLoading: true,
            maxClusterRadius: 50
        };
        
        const clusterOptions = { ...defaultOptions, ...options };
        const cluster = L.markerClusterGroup(clusterOptions);
        
        markers.forEach(marker => cluster.addLayer(marker));
        
        return cluster;
    }
    
    // Get address from coordinates (reverse geocoding)
    async reverseGeocode(lat, lng) {
        try {
            const response = await fetch(
                `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`
            );
            const data = await response.json();
            return data.display_name || 'Unknown location';
        } catch (error) {
            console.error('Reverse geocoding error:', error);
            return 'Unknown location';
        }
    }
    
    // Get coordinates from address (forward geocoding)
    async geocodeAddress(address) {
        try {
            const response = await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=1`
            );
            const data = await response.json();
            
            if (data.length > 0) {
                return {
                    lat: parseFloat(data[0].lat),
                    lng: parseFloat(data[0].lon),
                    address: data[0].display_name
                };
            }
            return null;
        } catch (error) {
            console.error('Geocoding error:', error);
            return null;
        }
    }
    
    // Add custom map controls
    addCustomControls(map) {
        // Location control
        const locationControl = L.control({ position: 'topright' });
        locationControl.onAdd = function() {
            const div = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
            div.innerHTML = `
                <a href="#" role="button" title="Find my location" onclick="locateUser(); return false;">
                    <i class="fas fa-location-arrow"></i>
                </a>
            `;
            return div;
        };
        locationControl.addTo(map);
        
        // Fullscreen control (if plugin available)
        if (typeof L.control.fullscreen !== 'undefined') {
            map.addControl(new L.control.fullscreen());
        }
        
        return { locationControl };
    }
    
    // Add search control to map
    addSearchControl(map, onResultSelect) {
        const searchControl = L.control({ position: 'topleft' });
        
        searchControl.onAdd = function() {
            const div = L.DomUtil.create('div', 'leaflet-control-search');
            div.innerHTML = `
                <div class="search-container">
                    <input type="text" placeholder="Search location..." class="form-control" id="mapSearch">
                    <button type="button" class="btn btn-primary" onclick="searchLocation()">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            `;
            
            // Prevent map events when interacting with search
            L.DomEvent.disableClickPropagation(div);
            
            return div;
        };
        
        searchControl.addTo(map);
        
        // Add search functionality
        const searchInput = document.getElementById('mapSearch');
        if (searchInput) {
            searchInput.addEventListener('keypress', async function(e) {
                if (e.key === 'Enter') {
                    const address = e.target.value.trim();
                    if (address) {
                        const result = await this.geocodeAddress(address);
                        if (result && onResultSelect) {
                            onResultSelect(result);
                        }
                    }
                }
            });
        }
        
        return searchControl;
    }
    
    // Save map state to localStorage
    saveMapState(map, key = 'mapState') {
        const state = {
            center: map.getCenter(),
            zoom: map.getZoom(),
            timestamp: Date.now()
        };
        
        WorkerApp.saveToLocalStorage(key, state);
    }
    
    // Restore map state from localStorage
    restoreMapState(map, key = 'mapState', maxAge = 24 * 60 * 60 * 1000) { // 24 hours
        const state = WorkerApp.getFromLocalStorage(key);
        
        if (state && (Date.now() - state.timestamp) < maxAge) {
            map.setView([state.center.lat, state.center.lng], state.zoom);
            return true;
        }
        
        return false;
    }
}

// Map event handlers and utilities
class MapEventHandler {
    constructor(map, utils) {
        this.map = map;
        this.utils = utils;
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Map move events
        this.map.on('moveend', () => {
            this.utils.saveMapState(this.map);
        });
        
        // Map zoom events
        this.map.on('zoomend', () => {
            this.utils.saveMapState(this.map);
        });
        
        // Map click events
        this.map.on('click', (e) => {
            this.onMapClick(e);
        });
        
        // Map ready event
        this.map.whenReady(() => {
            this.onMapReady();
        });
    }
    
    onMapClick(e) {
        // Custom map click handling
        console.log('Map clicked at:', e.latlng);
        
        // Example: Show coordinates in console
        if (window.WorkerApp) {
            WorkerApp.showNotification(
                'Location',
                `Clicked at: ${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`,
                'info',
                3000
            );
        }
    }
    
    onMapReady() {
        console.log('Map is ready');
        
        // Restore previous map state if available
        this.utils.restoreMapState(this.map);
    }
}

// Export for global use
window.MapUtils = MapUtils;
window.MapEventHandler = MapEventHandler;

// Global search function for search control
window.searchLocation = async function() {
    const searchInput = document.getElementById('mapSearch');
    if (!searchInput) return;
    
    const address = searchInput.value.trim();
    if (!address) return;
    
    try {
        const utils = new MapUtils();
        const result = await utils.geocodeAddress(address);
        
        if (result && window.map) {
            window.map.setView([result.lat, result.lng], 15);
            
            // Add temporary marker
            const marker = L.marker([result.lat, result.lng])
                .addTo(window.map)
                .bindPopup(result.address)
                .openPopup();
            
            // Remove marker after 5 seconds
            setTimeout(() => {
                window.map.removeLayer(marker);
            }, 5000);
        } else {
            WorkerApp.showNotification('Search', 'Location not found', 'warning');
        }
    } catch (error) {
        console.error('Search error:', error);
        WorkerApp.showNotification('Error', 'Search failed', 'error');
    }
};
