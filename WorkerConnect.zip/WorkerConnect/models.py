from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from sqlalchemy import func

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)  # 'client' or 'worker'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    worker_profile = db.relationship('WorkerProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    client_bookings = db.relationship('Booking', foreign_keys='Booking.client_id', backref='client')
    worker_bookings = db.relationship('Booking', foreign_keys='Booking.worker_id', backref='worker')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class WorkerProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    skills = db.Column(db.Text)  # JSON string of skills
    experience_years = db.Column(db.Integer, default=0)
    hourly_rate = db.Column(db.Float)
    bio = db.Column(db.Text)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    availability_status = db.Column(db.String(20), default='free')  # 'free', 'busy', 'dnd'
    rating = db.Column(db.Float, default=0.0)
    total_jobs = db.Column(db.Integer, default=0)
    is_active = db.Column(db.Boolean, default=True)
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    
    def update_last_seen(self):
        self.last_seen = datetime.utcnow()
        db.session.commit()
    
    def get_skills_list(self):
        import json
        try:
            return json.loads(self.skills) if self.skills else []
        except:
            return []
    
    def set_skills_list(self, skills_list):
        import json
        self.skills = json.dumps(skills_list)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    worker_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_description = db.Column(db.Text, nullable=False)
    required_skills = db.Column(db.Text)  # JSON string
    scheduled_date = db.Column(db.DateTime)
    duration_hours = db.Column(db.Float)
    total_amount = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'confirmed', 'in_progress', 'completed', 'cancelled'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Address information
    client_address = db.Column(db.Text)
    client_latitude = db.Column(db.Float)
    client_longitude = db.Column(db.Float)
    
    # Relationship
    feedback = db.relationship('Feedback', backref='booking', uselist=False, cascade='all, delete-orphan')
    
    def get_required_skills_list(self):
        import json
        try:
            return json.loads(self.required_skills) if self.required_skills else []
        except:
            return []
    
    def set_required_skills_list(self, skills_list):
        import json
        self.required_skills = json.dumps(skills_list)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Update worker's average rating when feedback is created
        if self.booking_id:
            booking = Booking.query.get(self.booking_id)
            if booking and booking.worker:
                self.update_worker_rating(booking.worker_id)
    
    def update_worker_rating(self, worker_id):
        # Calculate new average rating
        worker_profile = WorkerProfile.query.filter_by(user_id=worker_id).first()
        if worker_profile:
            avg_rating = db.session.query(func.avg(Feedback.rating)).join(Booking).filter(
                Booking.worker_id == worker_id
            ).scalar()
            worker_profile.rating = round(avg_rating, 1) if avg_rating else 0.0
            db.session.commit()

class Skill(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    category = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True)
